import React from "react";

const CardsDetails = () => {
  return <div className="">CardsDetails</div>;
};

export default CardsDetails;
